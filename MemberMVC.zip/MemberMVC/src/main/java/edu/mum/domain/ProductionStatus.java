package edu.mum.domain;

public enum ProductionStatus {
	INVALID,
	BASIC,
	DETAILS,
	PRODUCTION
	
}
