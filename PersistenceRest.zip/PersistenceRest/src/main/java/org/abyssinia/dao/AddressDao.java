package org.abyssinia.dao;

import org.abyssinia.domain.Address;

public interface AddressDao extends GenericDao<Address> {
      
}
