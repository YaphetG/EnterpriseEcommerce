package org.abyssinia.dao;

import org.abyssinia.domain.OrderPayment;

public interface OrderPaymentDao extends GenericDao<OrderPayment> {
      
}
