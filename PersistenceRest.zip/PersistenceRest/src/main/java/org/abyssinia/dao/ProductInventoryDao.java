package org.abyssinia.dao;

import org.abyssinia.domain.ProductInventory;

public interface ProductInventoryDao extends GenericDao<ProductInventory> {
      
}
