package org.abyssinia.persistance.util;

public class UrlList {
	public static final String PRODUCT = "/product";
	public static final String ID = "/{id}";
	public static final String ADD = "/add";
	public static final String UPDATE = "/update";
	public static final String USER = "/user";
	public static final String ORDER = "/order";
	
	
}
