package org.abyssinia.validation.groups;

import javax.validation.groups.Default;

public interface Details extends Default {

}
