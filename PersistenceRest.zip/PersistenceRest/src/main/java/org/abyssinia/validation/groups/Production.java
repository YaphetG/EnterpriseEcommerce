package org.abyssinia.validation.groups;

public interface Production extends Details {

}
